const express = require("express");
const { MongoClient } = require("mongodb");
const bodyParser = require("body-parser");

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static("public"));

// MongoDB connection URI
const uri = "mongodb://localhost:27017";

// Create a new MongoClient
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

let db;
client.connect()
  .then(() => {
    console.log("Connected to MongoDB");
    db = client.db("bankDB"); // Use the database
  })
  .catch(err => {
    console.error("Error connecting to MongoDB", err);
  });

// Add a customer
app.post("/addCustomer", (req, res) => {
  const { cust_id, cust_name, branch, balance } = req.body;
  const customer = { cust_id, cust_name, branch, balance };
  
  db.collection("customers").insertOne(customer)
    .then(result => {
      res.json({ message: "Customer added successfully!", customerId: result.insertedId });
    })
    .catch(err => {
      res.status(500).json({ error: "Error adding customer", details: err });
    });
});

// Get all customers
app.get("/getCustomers", (req, res) => {
  db.collection("customers").find().toArray()
    .then(customers => {
      res.json(customers);
    })
    .catch(err => {
      res.status(500).json({ error: "Error fetching customers", details: err });
    });
});

// Edit a customer's balance
app.put("/editCustomer/:id", (req, res) => {
  const { id } = req.params;
  const { balance } = req.body;
  
  db.collection("customers").updateOne({ _id: new MongoClient.ObjectId(id) }, { $set: { balance } })
    .then(result => {
      res.json({ message: "Customer balance updated successfully!" });
    })
    .catch(err => {
      res.status(500).json({ error: "Error updating customer", details: err });
    });
});

// Delete a customer
app.delete("/deleteCustomer/:id", (req, res) => {
  const { id } = req.params;
  
  db.collection("customers").deleteOne({ _id: new MongoClient.ObjectId(id) })
    .then(result => {
      res.json({ message: "Customer deleted successfully!" });
    })
    .catch(err => {
      res.status(500).json({ error: "Error deleting customer", details: err });
    });
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
